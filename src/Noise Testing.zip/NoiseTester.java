import javax.swing.*;

public class NoiseTester {
	public static void main(String[] args) {
		int[] s= {93,2904,412,301};
		int[][] c= { {193,211,307,149}, {7309,7541,7753,7237}, {15739,14281,15271,15817}, {26497,27997,25633,27259}};
		JFrame frame=new JFrame("Noise");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		NoisePanel panel;
		switch (0) {
		case 1:
			NoiseMaker2D n2;
			switch (5) {
			case 1:
				n2=new LinearInterpolatedNoiseMaker2D(s[0],c[0][0],c[1][0],c[2][0],c[3][0],c[0][1],c[1][1],c[2][1],c[3][1]);
				break;
			case 2:
				n2=new CosineInterpolatedNoiseMaker2D(s[0],c[0][0],c[1][0],c[2][0],c[3][0],c[0][1],c[1][1],c[2][1],c[3][1]);
				break;
			case 3:
				n2=new PerlinNoiseMaker2D(s[0],c[0][0],c[1][0],c[2][0],c[3][0],c[0][1],c[1][1],c[2][1],c[3][1],4);
				break;
			case 4:
				n2=new DoublePerlinNoiseMaker2D(s[0],c[0][0],c[1][0],c[2][0],c[3][0],c[0][1],c[1][1],c[2][1],c[3][1],3.5);
				break;
			case 5:
				n2=new AvolioNoiseMaker2D(s[0],c[0][0],c[1][0],c[2][0],c[3][0],c[0][1],c[1][1],c[2][1],c[3][1],8,new CosineInterpolatedNoiseMaker2D(s[1],c[0][2],c[1][2],c[2][2],c[3][2],c[0][3],c[1][3],c[2][3],c[3][3]));
				break;
			case 0:
			default:
				n2=new NonInterpolatedNoiseMaker2D(s[0],c[0][0],c[1][0],c[2][0],c[3][0],c[0][1],c[1][1],c[2][1],c[3][1]);
				break;
			}
			panel=new NoisePanel2D(n2,1000,500,20,10);
			break;
		case 0:
		default:
			NoiseMaker n;
			switch (5) {
			case 1:
				n=new LinearInterpolatedNoiseMaker(s[0],c[0][0],c[1][0],c[2][0],c[3][0]);
				break;
			case 2:
				n=new CosineInterpolatedNoiseMaker(s[0],c[0][0],c[1][0],c[2][0],c[3][0]);
				break;
			case 3:
				n=new PerlinNoiseMaker(s[0],c[0][0],c[1][0],c[2][0],c[3][0],5);
				break;
			case 4:
				n=new DoublePerlinNoiseMaker(s[0],c[0][0],c[1][0],c[2][0],c[3][0],3.5);
				break;
			case 5:
				n=new AvolioNoiseMaker(s[0],c[0][0],c[1][0],c[2][0],c[3][0],5,new CosineInterpolatedNoiseMaker(s[1],c[0][1],c[1][1],c[2][1],c[3][1]));
				break;
			case 0:
			default:
				n=new NonInterpolatedNoiseMaker(s[0],c[0][0],c[1][0],c[2][0],c[3][0]);
				break;
			}
			panel=new NoisePanel1D(n,1000,500,25);
			break;
		}
		//
		
		frame.setContentPane(panel);
		frame.pack();
		frame.setVisible(true);
	}
	
}
